#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct 13 11:26:08 2022

@author: d

Sources:
    https://github.com/christianversloot/machine-learning-articles/blob/main/how-to-create-a-cnn-classifier-with-keras.md
    https://docs.opencv.org/3.0-beta/doc/py_tutorials/py_gui/py_image_display/py_image_display.html
    https://stackoverflow.com/questions/54265959/predicting-my-own-image-in-cnn-using-keras
    https://towardsdatascience.com/visualizing-how-filters-work-in-convolutional-neural-networks-cnns-7383bd84ad2c
    https://medium.com/codex/kernels-filters-in-convolutional-neural-network-cnn-lets-talk-about-them-ee4e94f3319
    https://www.youtube.com/watch?v=KuXjwB4LzSA
"""

import cv2
import matplotlib.pyplot as plt
import numpy as np

from tensorflow.keras.datasets import mnist
from tensorflow.keras.layers import Conv2D, Dense, Dropout
from tensorflow.keras.layers import Flatten, MaxPooling2D
from tensorflow.keras.losses import categorical_crossentropy
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.utils import to_categorical

#%% Settings

# Set plot quality of matplotlib permanently to 300 dpi
plt.rcParams['figure.dpi'] = 300

#%% Model configuration

img_width, img_height = 28, 28
batch_size = 250
no_epochs = 25
no_classes = 10
validation_split = 0.2
verbosity = 1

#%% Load MNIST dataset

(input_train, target_train), (input_test, target_test) = mnist.load_data()

#%% Plot one number

plt.subplots(dpi=300)
plt.imshow(input_train[0], cmap="gray")
plt.show()

#%% Print one number

with np.printoptions(linewidth=np.inf):
    print(input_train[0])
    print("\nLabel:", target_train[0])

#%% Reshape data (fix resolution if necessary and add color channel)

input_train = input_train.reshape(input_train.shape[0], img_width, img_height, 1)
input_test = input_test.reshape(input_test.shape[0], img_width, img_height, 1)
input_shape = (img_width, img_height, 1) 

#%% Parse numbers as floats

input_train = input_train.astype('float32')
input_test = input_test.astype('float32')

#%% Convert into [0, 1] range

input_train = input_train / 255
input_test = input_test / 255

#%% Convert target vectors to categorical targets

target_train = to_categorical(target_train, no_classes)
target_test = to_categorical(target_test, no_classes)

#%% Create the model

model = Sequential()
model.add(Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=input_shape))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.25))
model.add(Flatten())
model.add(Dense(256, activation='relu'))
model.add(Dense(no_classes, activation='softmax'))

#%% Print the model

print(model.summary())

#%% Compile the model

model.compile(loss=categorical_crossentropy,
              optimizer=Adam(),
              metrics=['accuracy'])

#%% Train the model

history = model.fit(input_train, target_train,
                    batch_size=batch_size,
                    epochs=no_epochs,
                    verbose=verbosity,
                    validation_split=validation_split)

#%% Evaluate model and print performance on test data

score = model.evaluate(input_test, target_test, verbose=1)
print(f'Test loss: {score[0]:.3f} / Test accuracy: {score[1]:.3f}')

#%% Plot history for accuracy

plt.plot(history.history['accuracy'])
plt.plot(history.history['val_accuracy'])
plt.title('model accuracy')
plt.ylabel('accuracy')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

#%% Plot history for loss

plt.plot(history.history['loss'])
plt.plot(history.history['val_loss'])
plt.title('model loss')
plt.ylabel('loss')
plt.xlabel('epoch')
plt.legend(['train', 'test'], loc='upper left')
plt.show()

#%% Predict downloaded picture

# from opencv documentation:
# =============================================================================
# Use the function cv2.imread() to read an image. The image should be in the
# working directory or a full path of image should be given.
# Second argument is a flag which specifies the way image should be read.
# - cv2.IMREAD_COLOR : Loads a color image. Any transparency of image will be
# neglected. It is the default flag.
# - cv2.IMREAD_GRAYSCALE : Loads image in grayscale mode
# - cv2.IMREAD_UNCHANGED : Loads image as such including alpha channel
# Note
# Instead of these three flags, you can simply pass integers 1, 0 or -1
# respectively.
# =============================================================================

# load picture in grayscale
img = cv2.imread('Example_MNIST.png', 0)
print(img.shape)

# plot in grayscale
plt.imshow(img, cmap="gray")
plt.show()

# resize to 28 x 28 pixels
img = cv2.resize(img, (28, 28))
print(img.shape)

# Convert into [0, 1] range
img = img / 255

# add batch dimension (0) and channel dimension (3)
img = np.reshape(img, [1, 28, 28, 1])
print(np.argmax(model.predict(img)))

#%% predict own picture

# load picture in grayscale
img = cv2.imread('Example_MNIST_5.png', 0)
print(img.shape)

# plot in grayscale
plt.imshow(img, cmap="gray")
plt.show()

# resize to 28 x 28 pixels
img = cv2.resize(img, (28, 28))
print(img.shape)

# invert color
img = 255 - img

# Convert into [0, 1] range
img = img / 255
plt.imshow(img, cmap="gray")
plt.show()

# add batch dimension (0) and channel dimension (3)
img = np.reshape(img, [1, 28, 28, 1])
print(np.argmax(model.predict(img)))
